Par Arthur Vandroogenbroek et Guillaume van der Rest

bioinfo.py contient 4 fonctions, toutes 4 realisant des tests concernant l'ADN. La premiere verifie que la sequence est bien de l'adn, cad qu'elle ne contient que des a,g,c,t,A,G,C,T. La deuxieme essaye de trouver une sequence p a l'interieur d'une sequence s et retourne les positions. La troisieme retourne la "quantite de difference" entre deux sequences d'une même longueur, cad le nombre d'entrees differentes. La quatrieme cherche le palindrome le plus long dans la sequence et le retourne en string.

test.py teste les 4 fonctions, chacune avec 3 sous-tests, verifiant des cas particuliers, etc... 

Difficultes rencontrees: La premiere et troisieme fonction etaient tres faciles, la deuxieme nous a pose un peu plus problème et la quatrieme a requis beaucoup plus de reflexion et d'essai-erreur. Les tests etaient faciles a coder.
